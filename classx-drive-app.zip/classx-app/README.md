# Class X Drive — App with Push Notifications

Two parts:
- **frontend/** — the app itself (index.html, service worker, manifest, icons, admin.html)
- **backend/** — a small Node.js server that stores subscriptions and sends push notifications

You need to deploy the backend somewhere with a real HTTPS URL before push notifications will work.
Recommended host: **Render** (free tier, no credit card, easiest for a small Node app).

---

## Step 1 — Get a GitHub repo

1. Create a free account at github.com if you don't have one.
2. Create a new repository (e.g. `classx-drive-app`), and upload this whole folder to it
   (drag-and-drop on github.com works, or use `git push` if you're comfortable with git).

## Step 2 — Generate your VAPID keys

VAPID keys are how the push service verifies your server is allowed to send notifications
to a subscribed browser. Generate them once, on your own computer or in any Node environment:

```bash
npx web-push generate-vapid-keys
```

This prints a **Public Key** and a **Private Key**. Save both somewhere safe — you'll paste
them into Render in Step 3. Never commit the private key to GitHub.

## Step 3 — Deploy the backend on Render

1. Go to render.com → sign up (GitHub login is fastest) → **New +** → **Web Service**.
2. Connect the GitHub repo you created in Step 1.
3. Set:
   - **Root Directory:** `backend`
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free
4. Under **Environment Variables**, add:
   - `VAPID_PUBLIC_KEY` = (the public key from Step 2)
   - `VAPID_PRIVATE_KEY` = (the private key from Step 2)
   - `ADMIN_KEY` = any password you make up — this is what lets you send notifications later
5. Click **Create Web Service**. Render will build and deploy it. Once it's live you'll get
   a URL like `https://classx-drive-push.onrender.com` — copy it.

Note: Render's free tier spins the server down after 15 minutes of no traffic, and spins
back up (takes ~30–50 seconds) on the next request. That's fine for this use case — it just
means the very first notification after a quiet period sends a little slower.

## Step 4 — Point the app at your backend

Open `frontend/index.html`, find this line near the bottom:

```js
const BACKEND_URL = "https://YOUR-BACKEND-URL-HERE";
```

Replace it with your real Render URL from Step 3, e.g.:

```js
const BACKEND_URL = "https://classx-drive-push.onrender.com";
```

## Step 5 — Host the frontend

Any static host works — GitHub Pages is free and simple:

1. In your GitHub repo settings → **Pages** → set source to the `frontend` folder on your main branch.
2. GitHub gives you a URL like `https://yourname.github.io/classx-drive-app/`.
3. Push notifications only work over HTTPS — GitHub Pages already gives you that.

## Step 6 — Try it

1. Open your GitHub Pages URL on your phone or laptop.
2. Go to the **More** tab → tap **Enable notifications** → allow the permission prompt.
3. Open `frontend/admin.html` (host it the same way, or open it locally) and send a test notification:
   - Backend URL: your Render URL
   - Admin key: whatever you set in Step 3
   - Title / message: anything
4. You should get a real OS-level notification within a few seconds — even with the app closed.

## Notes on scaling this up later

- Subscriptions are currently stored in a JSON file on the server. That's fine for a class
  of a few hundred students, but on Render's free tier the filesystem resets on redeploys —
  so subscribers would need to re-enable notifications after you push an update. If that
  matters, swap the JSON file for a free database like Supabase or MongoDB Atlas later.
- Keep your `ADMIN_KEY` private — anyone with it can broadcast to every subscriber.
